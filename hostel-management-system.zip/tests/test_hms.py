import unittest, tempfile
from hms.validators import valid_phone, clean_name

class ValidatorTests(unittest.TestCase):
    def test_phone(self):
        self.assertTrue(valid_phone("9876543210"))
        self.assertFalse(valid_phone("123"))
        self.assertFalse(valid_phone("abcdefghij"))
    def test_name(self):
        self.assertEqual(clean_name(" Ravi "), "Ravi")
        with self.assertRaises(ValueError): clean_name("")

if __name__=="__main__": unittest.main()

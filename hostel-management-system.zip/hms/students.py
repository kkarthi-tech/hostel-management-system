from .database import connect
from .validators import clean_name, valid_phone

def add_student(student_id, name, phone, room_no):
    student_id = student_id.strip()
    if not student_id:
        raise ValueError("Student ID cannot be empty.")
    name = clean_name(name)
    if not valid_phone(phone):
        raise ValueError("Phone number must contain exactly 10 digits.")
    with connect() as con:
        room = con.execute("SELECT capacity FROM rooms WHERE room_no=?", (room_no,)).fetchone()
        if room is None:
            raise ValueError("Room does not exist.")
        count = con.execute("SELECT COUNT(*) FROM students WHERE room_no=?", (room_no,)).fetchone()[0]
        if count >= room[0]:
            raise ValueError("Room is full.")
        con.execute("INSERT INTO students(student_id,name,phone,room_no) VALUES(?,?,?,?)",
                    (student_id,name,phone,room_no))
        con.commit()

def list_students():
    with connect() as con:
        return con.execute("SELECT student_id,name,phone,room_no FROM students ORDER BY student_id").fetchall()

def find_student(student_id):
    with connect() as con:
        return con.execute("SELECT student_id,name,phone,room_no FROM students WHERE student_id=?",
                           (student_id.strip(),)).fetchone()

def remove_student(student_id):
    with connect() as con:
        cur=con.execute("DELETE FROM students WHERE student_id=?", (student_id.strip(),))
        con.commit()
        return cur.rowcount > 0

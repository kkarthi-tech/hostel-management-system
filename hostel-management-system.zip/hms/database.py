import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "hostel.db"

def connect():
    return sqlite3.connect(DB_PATH)

def initialize():
    with connect() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS rooms (
            room_no INTEGER PRIMARY KEY, capacity INTEGER NOT NULL CHECK(capacity > 0))""")
        con.execute("""CREATE TABLE IF NOT EXISTS students (
            student_id TEXT PRIMARY KEY, name TEXT NOT NULL, phone TEXT NOT NULL,
            room_no INTEGER NOT NULL REFERENCES rooms(room_no))""")
        # Create a simple set of rooms if the room table is empty.
        if con.execute("SELECT COUNT(*) FROM rooms").fetchone()[0] == 0:
            con.executemany("INSERT INTO rooms(room_no,capacity) VALUES (?,?)",
                            [(101,2),(102,2),(103,2),(104,3),(105,3)])
        con.commit()

def valid_phone(phone):
    return phone.isdigit() and len(phone) == 10

def clean_name(name):
    name = name.strip()
    if not name or len(name) > 60:
        raise ValueError("Name must contain 1 to 60 characters.")
    return name

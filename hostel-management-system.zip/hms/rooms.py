from .database import connect

def room_status():
    with connect() as con:
        rooms=con.execute("SELECT room_no,capacity FROM rooms ORDER BY room_no").fetchall()
        result=[]
        for room_no,capacity in rooms:
            occupied=con.execute("SELECT COUNT(*) FROM students WHERE room_no=?", (room_no,)).fetchone()[0]
            result.append((room_no,capacity,occupied,capacity-occupied))
        return result

def available_rooms():
    return [r for r in room_status() if r[3] > 0]

def summary():
    with connect() as con:
        students=con.execute("SELECT COUNT(*) FROM students").fetchone()[0]
    rooms=room_status()
    return students, sum(r[2] for r in rooms), sum(r[3] for r in rooms)
